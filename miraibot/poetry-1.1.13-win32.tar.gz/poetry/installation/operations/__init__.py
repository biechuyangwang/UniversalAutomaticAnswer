from .install import Install
from .uninstall import Uninstall
from .update import Update
