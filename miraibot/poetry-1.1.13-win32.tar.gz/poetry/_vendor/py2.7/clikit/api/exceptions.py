class CliKitException(Exception):
    """
    Base class for CliKit exceptions
    """

    pass
