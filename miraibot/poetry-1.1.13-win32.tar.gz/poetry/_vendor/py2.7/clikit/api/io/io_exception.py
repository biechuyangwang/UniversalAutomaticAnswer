class IOException(RuntimeError):
    """
    Thrown if an error happens during I/O.
    """
