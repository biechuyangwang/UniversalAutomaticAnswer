class Alignment:
    """
    Constants for text alignment.
    """

    LEFT = 0
    RIGHT = 1
    CENTER = 2
