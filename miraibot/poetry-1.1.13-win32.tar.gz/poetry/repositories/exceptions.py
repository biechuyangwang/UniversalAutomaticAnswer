class RepositoryError(Exception):

    pass


class PackageNotFound(Exception):

    pass
